﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class block : MonoBehaviour
{
    public Text celltext;
    private Image cellimage;
    private RectTransform cellrect;
    private gamedata gmdata;
    private board Board;


    public int column;
    public int row;


    public int datanum;
    float width;
    float height;
    int tilenum;
    Color tilecolor;

    private static readonly string sizex = "sizex";
    private static readonly string sizey = "sizey";


    void Start()
    {
        Board = GameObject.FindWithTag("GameController").GetComponent<board>();
        gmdata = GameObject.FindWithTag("EditorOnly").GetComponent<gamedata>();
        celltext.enabled = false;
        cellimage = GetComponent<Image>();
        cellrect = GetComponent<RectTransform>();
        // Debug.Log(gmdata.saveData.Tile[datanum].tilenumber);

        width = PlayerPrefs.GetFloat(sizex);
        height = PlayerPrefs.GetFloat(sizey);
        cellrect.sizeDelta = new Vector2(width, height);

        cellimage.color = new Color(1f, 1f, 1f, 1f);
        if(gmdata.saveData != null){
            tilenum = gmdata.saveData.tilenumber[datanum];
            tilecolor = new Color((gmdata.saveData.Rcolor[datanum]), (gmdata.saveData.Gcolor[datanum]), (gmdata.saveData.Bcolor[datanum]), (gmdata.saveData.Acolor[datanum]));
        }
        // StartCoroutine(startco());   
    }
    // IEnumerator startco(){
    //     yield return new WaitForSeconds(1f);
        
        
    // }


    public void press(){
        celltext.enabled = true;
        celltext.text = tilenum.ToString();
        cellimage.color = tilecolor;
        Board.Checksurrouding(column,row);

    }

    public void blockpress(){
        celltext.enabled = true;
        celltext.text = tilenum.ToString();
        cellimage.color = tilecolor;
    }

    

   
}
