﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;



[Serializable]
public class SaveData{
    public int[] tilenumber;
    public float[] Rcolor;
    public float[] Gcolor;
    public float[] Bcolor;
    public float[] Acolor;

    

}

public class gamedata : MonoBehaviour
{
    public static gamedata gameData;
    public SaveData saveData;
    public int xcount;
    public int ycount;
    
    // Start is called before the first frame update
    
    void Awake(){
        xcount = 0;
        ycount = 0;
        if(gameData == null){
            DontDestroyOnLoad(this.gameObject);
            gameData = this;
        }else{
            Destroy(this.gameObject);
        }
        
        load();
        

        
    }
    public void Setsize(){
        saveData.tilenumber = new int[(xcount*ycount)];
        saveData.Rcolor = new float[(xcount*ycount)];
        saveData.Gcolor = new float[(xcount*ycount)];
        saveData.Bcolor = new float[(xcount*ycount)];
        saveData.Acolor = new float[(xcount*ycount)];

        


    }
    

    public void save(){
        BinaryFormatter formatter = new BinaryFormatter();

        FileStream file = File.Open(Application.persistentDataPath + "/Tiledata.dat", FileMode.Create);

        SaveData data = new SaveData();

        data = saveData;

        formatter.Serialize(file, data);

        file.Close();

        Debug.Log("saved");

    }

    public void load(){

        if(File.Exists(Application.persistentDataPath + "/Tiledata.dat")){

            BinaryFormatter formatter = new BinaryFormatter();

            FileStream file = File.Open(Application.persistentDataPath + "/Tiledata.dat", FileMode.Open);

            saveData = formatter.Deserialize(file) as SaveData;

            file.Close();

            Debug.Log("loaded");

        }


    }

    private void OnApplicationQuit(){
        save();
    }

    private void OnDisable(){
        save();
    }
}
