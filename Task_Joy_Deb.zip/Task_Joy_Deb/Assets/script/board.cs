﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class board : MonoBehaviour
{
    public int countx;
    public int county;

    
    public GameObject block;

    public GameObject[,] allblocks;
    public int areaOfintrest;

    private gamedata gmdata;

    float totalwidth;
    float totalheight;
    int currentcount;
    int celldatacount;

    float cellwidth;
    float cellheight;
    Color currentcolor;


    private static readonly string sizex = "sizex";
    private static readonly string sizey = "sizey";

    private Rect safearea;
    private RectTransform rectT;

    void Awake(){
        rectT = GetComponent<RectTransform>();
        safearea = Screen.safeArea;
        refresh(0f, 0f);
        float diff1 = Display.main.systemWidth - Screen.safeArea.width;
        float diff2 = Display.main.systemHeight - Screen.safeArea.height;
        // float diff2 = 1520f - 1280f;
        // float diff1 = 860f - 720f;
        refresh(diff1*0.5f, diff2*0.5f);

    }
    void refresh(float x, float h){
        float y = rectT.offsetMin.y;
        rectT.offsetMax = new Vector2(-x, -h);
        rectT.offsetMin = new Vector2(x, y);

    }
    



    void Start()
    {
        StartCoroutine(startco());
                   
    }
    IEnumerator startco(){
        yield return new WaitForSeconds(1f);
        gmdata = GameObject.FindWithTag("EditorOnly").GetComponent<gamedata>();
        gmdata.xcount = countx;
        gmdata.ycount = county;
        gmdata.Setsize();
        allblocks = new GameObject[countx , county];
        
        totalwidth = (Screen.width) - (rectT.offsetMin.x - rectT.offsetMax.x);
        totalheight = (Screen.height) - (rectT.offsetMin.y - rectT.offsetMax.y);

        calculatedimension();
        Setup();
    }


    void Setup(){
        celldatacount = 0;
        currentcount = 1;
        for(int i = 0; i < county; i++){
            for(int j = 0; j < countx; j++){
                GameObject cell = Instantiate(block, new Vector3(0f, 0f, 0f), Quaternion.identity);
                cell.transform.SetParent(this.transform, false);
                block blockCS = cell.GetComponent<block>();
                blockCS.datanum = celldatacount;
                blockCS.column = j;
                blockCS.row = i;

                colorselect();

                RectTransform cellrect = cell.GetComponent<RectTransform>();
                cellrect.anchoredPosition = new Vector2((cellwidth * 2f * j) + cellwidth, ((cellheight * 2f * i) + cellheight)* -1f);
                allblocks[j,i] = cell;
                

            }
        }
    }







    void calculatedimension(){
        float xwidth = totalwidth / countx;
        float yheight = totalheight / county;

        cellwidth = xwidth / 2f;
        cellheight = yheight / 2f;

        PlayerPrefs.SetFloat(sizex, xwidth);
        PlayerPrefs.SetFloat(sizey, yheight);

    }

    void colorselect(){
        float R = Random.Range(0.3f, 1f);
        float G = Random.Range(0.3f, 1f);
        float B = Random.Range(0.3f, 1f);
        if(gmdata.saveData != null){
            gmdata.saveData.tilenumber[celldatacount] = currentcount;
            gmdata.saveData.Rcolor[celldatacount] = R;
            gmdata.saveData.Gcolor[celldatacount] = G;
            gmdata.saveData.Bcolor[celldatacount] = B;
            gmdata.saveData.Acolor[celldatacount] = 1f;

        }
        // Tile[celldatacount].tilenumber = currentcount;
        // Tile[celldatacount].tilecolor = currentcolor;


        celldatacount += 1;
        currentcount += 1;


        
    }


    public void Checksurrouding(int colomn, int row){
        for(int p = 1; p < areaOfintrest + 1; p++){
            for(int i = colomn - p; i <= colomn + p; i ++){
                for(int j = row - p; j <= row + p; j ++){
                    if(i >= 0 && i < countx && j >= 0 && j < county){
                        if(allblocks[i, j] != null){
                            allblocks[i, j].GetComponent<block>().blockpress();

                        }
                    }
                }
            }
        }
        
    }


    
}
