﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class weapon{
    public int totalammo;
    public int megammo;
    public float firerate;
    public float refillrate;
    public float damagepershot;
    public int currentammo;

}



public class weaponsystem : MonoBehaviour
{
    public weapon primaryweapon1;
    public weapon primaryweapon2;

    public weapon secondaryweapon;

    private weapon currentweapon;
    public int totalammo;
    public int megammo;
    private float firerate;
    private float refillrate;
    private float damagepershot;
    public int currentammo;
    




    void Start()
    {
        currentweapon = primaryweapon1;
        selectweapon(currentweapon);
        loadreload();
        
    }

    void selectweapon(weapon Gun){
        totalammo = Gun.totalammo;
        megammo = Gun.megammo;
        firerate = Gun.firerate;
        refillrate = Gun.refillrate;
        damagepershot = Gun.damagepershot;
        currentammo = Gun.currentammo;
    }

    public void loadreload(){
        int diff = megammo - currentammo;
        totalammo -= diff;
        currentammo = megammo;

    }
    public void shot(){
        if(currentammo > 0){
            currentammo -= 1;

        }else{
            loadreload();
        }

    }

    void changeweapon(weapon Gun){
        Gun.totalammo = totalammo;
        Gun.currentammo = currentammo;
    }

    public void switchprimary1(){
        changeweapon(currentweapon);
        currentweapon = primaryweapon1;
        selectweapon(primaryweapon1);
        if(currentammo == 0){
            loadreload();
        }
    }

    public void switchprimary2(){
        changeweapon(currentweapon);
        currentweapon = primaryweapon2;
        selectweapon(primaryweapon2);
        if(currentammo == 0){
            loadreload();
        }
    }

    public void switchpsecondary1(){
        changeweapon(currentweapon);
        currentweapon = secondaryweapon;
        selectweapon(secondaryweapon);
        if(currentammo == 0){
            loadreload();
        }
    }

    void Update(){
    }

    
}
